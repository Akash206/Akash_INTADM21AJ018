$(document).ready(() => {
    $("#btn").click(() => {
      var textArea = $("#myTextArea").val();
      console.log(textArea);
      $("#message").append(textArea);
    });
  
    $("#message").click(function () {
      console.log("Clicked on message");
      let emoji = document.createElement("img");
      emoji.src =
      "https://cdn.pixabay.com/photo/2013/07/18/10/56/smiley-163510_960_720.jpg";
      emoji.width = 70;
      emoji.height = 60;
      $(this).replaceWith(emoji);
    });
  });