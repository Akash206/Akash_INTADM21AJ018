export interface department
{
    DepartmentId:number;
    DepartmentName:string;
}